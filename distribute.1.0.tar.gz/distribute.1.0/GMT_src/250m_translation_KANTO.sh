#!/bin/sh

f77=gfortran  # fortran

flag_d=0    # Display flag -> 1 to display

# For advection vectors
h_mag=40 #40

for mesh_n in 06 
do

for var in radar
    do

echo 'for ' $var

plot_adv=1     #  To plot advection vectors

dirdate=20170718 # directory date

sfiledate=20170718 # initial run date
efiledate=20170718 # final run date

stime=1440 # Modify the initial start time for the first day
etime=1440

date=${sfiledate}
resolution="test"
dxy=0.25
while [ ${date} -le ${efiledate} ]
do

yr=`echo $date | cut -c1-4`
yr1=`echo $date | cut -c3-4`
mn=`echo $date | cut -c5-6`
dy=`echo $date | cut -c7-8`

time=${stime}
endtime=${etime}
if [ $date -eq ${sfiledate} ];then
time=${stime}
time=`expr $time + 0`  #vanish head '0'
elif [ $date -eq ${efiledate} ];then
endtime=${etime}
fi

while [ ${time} -le ${endtime} ]
do
time0=`printf "%04d" $time` # "%04d" means to keep formating of 4 characters
hour=`echo $time0 | cut -c1-2`
minute=`echo $time0 | cut -c3-4`
if [ ${minute} -le 59 ];then
#echo ${date} ${time0}

snum=0
enum=12

while [ $snum -le $enum ]
do

   snum=`expr $snum + 0`
   numz=`printf "%02d" ${snum}`
   pred_time=`expr $snum \* 5`


if [ $var == 'radar' ]; then
inputfile=../output/hmesh${mesh_n}/prediction/advection/${yr1}${mn}${dy}${hour}${minute}-${numz}.dat 
adv_x=../output/hmesh${mesh_n}/prediction/adv_uv/radar/${yr1}${mn}${dy}${hour}${minute}x.dat 
adv_y=../output/hmesh${mesh_n}/prediction/adv_uv/radar/${yr1}${mn}${dy}${hour}${minute}y.dat 
out_folder=./figure/${dirdate}/hmesh${mesh_n}/${var}/prediction/

elif [ $var == 'radar_no_decay' ]; then
inputfile=/MUTEPPO/nakabuchi/translation/output/hmesh${mesh_n}/pre_no_decay/advection/${yr1}${mn}${dy}${hour}${minute}-${numz}.dat 
adv_x=/MUTEPPO/nakabuchi/translation/output/hmesh${mesh_n}/pre_no_decay/adv_uv/radar/${yr1}${mn}${dy}${hour}${minute}x.dat 
adv_y=/MUTEPPO/nakabuchi/translation/output/hmesh${mesh_n}/pre_no_decay/adv_uv/radar/${yr1}${mn}${dy}${hour}${minute}y.dat 
out_folder=/MUTEPPO/nakabuchi/GMT/translation/figure/${dirdate}/hmesh${mesh_n}/${var}/prediction/

elif [ $var == 'Rn' ] || [ $var == 'Rn_Ro' ]; then
#still need to set the variable here
inputfile=/MUTEPPO/nakabuchi/translation/output/hmesh${mesh_n}/from_${PPI_number}/pre_no_decay/advection_${var}/${yr1}${mn}${dy}${hour}${minute}-${numz}.dat
    adv_x=/MUTEPPO/nakabuchi/translation/output/hmesh${mesh_n}/from_${PPI_number}/pre_no_decay/adv_uv/Rn/${yr1}${mn}${dy}${hour}${minute}x.dat
    adv_y=/MUTEPPO/nakabuchi/translation/output/hmesh${mesh_n}/from_${PPI_number}/pre_no_decay/adv_uv/Rn/${yr1}${mn}${dy}${hour}${minute}y.dat
out_folder=/MUTEPPO/nakabuchi/GMT/translation/figure/${dirdate}/hmesh${mesh_n}/${PPI_number}/${var}/pre_no_decay/

fi

echo $inputfile

if [ -e ${inputfile} ]; then
echo 'input file is: '$inputfile

#map_out=../MAP/map_1km_kanuki_LF_1_GMT.dat
cat > mlit.3km.f90 << eof
!=======================================================================
! Program for reading Jogamori radar data
!=======================================================================
program mlit_3km

    implicit none

    real,parameter      ::  slon=137.0 
    real,parameter      ::  slat=34.0   
    real,parameter      ::  dxy=0.25
    integer, parameter  ::  nx=1600
    integer, parameter  ::  ny=1600
    integer             ::  i,j,k
    character(len=250)  ::  ifile
    character(len=250)  ::  ifilex
    character(len=250)  ::  ifiley
    real,dimension(nx,ny)   ::  lon
    real,dimension(nx,ny)   ::  lat
    real,dimension(nx,ny)   ::  rr, adv_x, adv_y, adv_xy, dir_xy, rr_gr
    real, parameter         ::  h_mag = ${h_mag}.0
    real, parameter         ::  pi = 4. * atan(1.0d0)
    
    ifile = '${inputfile}'
    ifilex= '${adv_x}'
    ifiley= '${adv_y}'

    open(10, file = ifile , status = 'old', action = 'read')
    open(11, file = ifilex, status = 'old', action = 'read')
    open(12, file = ifiley, status = 'old', action = 'read')
    
    read(10,*) ((rr(i,j)   , i = 1, nx), j = 1, ny)
    read(11,*) ((adv_x(i,j), i = 1, nx), j = 1, ny)
    read(12,*) ((adv_y(i,j), i = 1, nx), j = 1, ny)

    rr_gr = rr

    close(10)
    close(11)
    close(12)

    do j = 1, ny
        do i = 1, nx
            !lon(i,j) = slon + real(i-1) * 0.0109679849 * dxy
            !lat(i,j) = slat + real(j-1) * 0.00901464 * dxy
            lon(i,j) = slon + real(i-1) * 0.003125 !250m mesh
            lat(i,j) = slat + real(j-1) * 0.002083 !250m mesh


            if (rr(i,j) > 9999.) then
                rr(i,j) = 0.
                rr_gr(i,j) = -9999.9
            endif
        enddo
    enddo

    do j = 1, ny
        do i = 1, nx
             adv_xy(i,j) = sqrt( (adv_x(i,j) / h_mag) ** 2. + (adv_y(i,j) / h_mag) ** 2. ) 
             dir_xy(i,j) = atan2((adv_x(i,j) / h_mag), (adv_y(i,j) / h_mag)) * 180.0 / pi
        enddo
    enddo


    open(29,file='out_gr.txt')
    open(30,file='out.txt')
    open(31,file='adv_xy.dat')
    open(32,file='adv_dir.dat')
    open(33,file='adv_mag.dat')

    do j = 1, ny
        do i = 1, nx
            write(29,*) lon(i,j), lat(i,j), rr_gr(i,j)
            write(30,*) lon(i,j), lat(i,j), rr(i,j)
            write(31,*) lon(i,j), lat(i,j), dir_xy(i,j), adv_xy(i,j)
            write(32,*) lon(i,j), lat(i,j), dir_xy(i,j)
            write(33,*) lon(i,j), lat(i,j), adv_xy(i,j)
        enddo 
    enddo

    close(30)
    close(31)
    close(32)
    close(33)

end program mlit_3km

eof

${f77} -O2 ./mlit.3km.f90 -o mlit.3km.exe
./mlit.3km.exe
rm ./mlit.3km.f90 ./mlit.3km.exe

#=======================================================================


#Set GMT parameters
gmtset PAGE_ORIENTATION portrait
gmtset PAPER_MEDIA Custom_600x550   # Original
#gmtset PAPER_MEDIA Custom_500x400
gmtset ANOT_FONT Helvetica
gmtset ANOT_FONT_SIZE 12  # Original: 15
gmtset LABEL_FONT_SIZE 13  # Original: 10 
gmtset BASEMAP_TYPE plain
gmtset GRID_PEN_PRIMARY 0.5p
gmtset FRAME_PEN 1p
gmtset X_ORIGIN 2.0
gmtset Y_ORIGIN 2.0
gmtset PLOT_DEGREE_FORMAT +ddd:mm:ssF
gmtset HEADER_FONT Bookman-Demi
gmtset HEADER_FONT_SIZE 24
gmtset HEADER_OFFSET 0.5c
PROJ="-Jm10.8"
#LIMS_D="-R137.0/142.0/34.0/37.33333"
LIMS_D="-R139.0/140.3/35.0/36.0"
LIMS_3R="-R137.0/142.0/34.0/37.33333"
UNDEF='-9999.9'
file_grd='tmp.grd'
cpt_=color_rr_MLIT.cpt
PSFILE=out.eps
int="0.003125/0.0020833312"

pscoast $PROJ $LIMS_D -C  -Lf133.95/33.0/33/50+u -S250/250/250 -K > $PSFILE    # This is for the scale bar distance

case $var in
    Ro)
    title_map="Orographic Rainfall"
    echo 0.0 16 23 0 19 LB $title_map ${Height} ${date} "-" ${hour}:${minute}  | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE 
    echo 7.4 14.8 19 0 0 RB "*Generated in this layer*"  | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE 
    ;;
    Rototal)
    title_map="Total Orographic Rainfall"
    echo 0.0 16 23 0 19 LB $title_map ${date} "-" ${hour}:${minute}  | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE
#    echo 6.7 14.8 19 0 0 RB "*Before Recombine*"  | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE 
    ;;
    Rn)
    title_map="Prediction - Rn"
    echo 0.0 16 23 0 19 LB $title_map ${date} "-" ${hour}:${minute} "->" ${pred_time} "min" | pstext -Jx1 -R0./50/0/60 -K -O  >> $PSFILE
    #echo 6.7 14.8 19 0 0 RB "*Before Recombine*"  | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE 
    ;;
    radar|radar_with_decay)
    title_map="Prediction - radar"
    echo 0.0 16 23 0 19 LB $title_map ${date} "-" ${hour}:${minute} "->" ${pred_time} "min" | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE
#    echo 6.7 14.8 19 0 0 RB "*Before Recombine*"  | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE 
    ;;
    Rn_Ro)
    title_map="Prediction with Ro"
    echo 0.0 16 23 0 19 LB $title_map ${date} "-" ${hour}:${minute} "->" ${pred_time} "min" | pstext -Jx1 -R0./50/0/60 -K -O  >> $PSFILE
    #echo 6.7 14.8 19 0 0 RB "*Before Recombine*"  | pstext -Jx1 -R0./50/0/60 -K -O >> $PSFILE 
    ;;
    *)
    echo "Map title for ${var} not set"
    echo "Exiting program"
    exit
    ;;
esac


#awk '$3 > 0. {print $1, $2, $3}' ./out.txt | psxy -Jm4 -C$cpt_ -R133.5/137.3/32.8/36.0 -Ss0.2 -O -K >> $PSFILE      # MLIT color palette
awk '{print  $3}' ./out_gr.txt > out_gr2.dat 
awk '{print  $3}' ./out.txt > out_gr2.dat 
xyz2grd out_gr2.dat $LIMS_3R -G$file_grd -I$int -ZBLa -N$UNDEF -F 
grdimage $file_grd $LIMS_D $PROJ -C$cpt_ -K -O >> $PSFILE

psxy map.pref -J -R -m -W2/0/0/0 -O -K >> $PSFILE


pscoast -J -R -Ba1.0f0.25:""::."":neSW -N1 -N2 -Dh -W2 -O -K >> $PSFILE
#-Ba1.0f0.25/a1f0.25SWne
echo 10.5 1.25 > tmp1
echo 10.9 1.25 >> tmp1
psxy tmp1 -Jx1 -R0/50/0/50 -W4/67/135/233 -K -O >> $PSFILE
gmtset FRAME_PEN 1p

psscale -C$cpt_ -D16.3/6.5/10/0.5  -L -E1 -B:"Rainfall Intensity (mm/h)":/:"": -O -K >> $PSFILE #bigger area

psxy map.pref -J -R -m -W2/0/0/0 -O -K >> $PSFILE
 
if [ $plot_adv -eq 1 ]; then

block_size=10

blockmean adv_dir.dat -I${block_size}k $LIMS_D > dirmean.dat
blockmean adv_mag.dat -I${block_size}k $LIMS_D > magmean.dat
#blockmean adv_xy.dat -I${block_size}k $LIMS_D > adv_xy_mean.dat
join -j1 1 -j2 1 -o 1.1 1.2 1.3 2.3 ./dirmean.dat ./magmean.dat > adv_xy_mean.dat
#awk '{print $1,$2,atan2($3,$4)*180/3.1415,sqrt(($3)^2+($4)^2)/"'"$block_size"'"}' uvjoin.txt > uvmean.txt

psxy adv_xy_mean.dat $PROJ $LIMS_D  -SV0.075/0.350/0.15 -Gblack -O >> $PSFILE


xyz2grd $adv_x $LIMS_3R -Gadvx.grd -I$int -ZBLa -N$UNDEF -F 
xyz2grd $adv_y $LIMS_3R -Gadvy.grd -I$int -ZBLa -N$UNDEF -F 

fi


#=======================================================================

if [ $flag_d -eq 1 ]; then
    display $PSFILE
fi


    mkdir -p $out_folder
      echo 'outpufile is: ' ${out_folder}${date}${hour}${minute}-$numz.gif
   convert -density 100 $PSFILE ${out_folder}${date}${hour}${minute}-$numz.gif

fi
   snum=`expr $snum + 0`
   snum=`expr $snum + 1`
done	# [ $snum -le $enum ]
fi

   time=`expr $time + 5`
done #while [ ${time} -le ${endtime} ]

   date=`expr $date + 1`
done  #while [ ${date} -le ${efiledate} ]


rm tmp* out.txt out.eps 
rm -f delt_time.cpt wgt.cpt


snum=0

done #var

done #mesh_n
